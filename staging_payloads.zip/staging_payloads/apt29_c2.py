from flask import Flask, request
from datetime import datetime

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
@app.route("/beacon", methods=["GET", "POST"])
def beacon():
    now = datetime.utcnow().isoformat()
    print("\n=== Beacon received ===")
    print(f"Time (UTC): {now}")
    print(f"Method    : {request.method}")
    print(f"Path      : {request.path}")
    print(f"Args      : {dict(request.args)}")
    try:
        body = request.get_data()
        if body:
            print(f"Body      : {body[:200]!r}")
        else:
            print("Body      : <empty>")
    except Exception as e:
        print(f"Body read error: {e}")
    print("========================")
    return "OK", 200

if __name__ == "__main__":
    # Listen on all interfaces, port 8080
    app.run(host="0.0.0.0", port=8080)
